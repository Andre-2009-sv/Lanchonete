let nomeLanchonete = "Sabor Real";
let horaAtual = 19;

let textoStatus = document.getElementById("mensagem-status");
let textoHorario = document.getElementById("detalhe-horario");

if (horaAtual >= 18 && horaAtual <= 23) {
    textoStatus.textContent = "A " + nomeLanchonete + " está ABERTA agora! Faça seu pedido.";
    textoStatus.style.color = "green";
} else {
    textoStatus.textContent = "A " + nomeLanchonete + " está FECHADA no momento.";
    textoStatus.style.color = "red";
}

textoHorario.textContent = "Horário de funcionamento: 18h às 23h. Horário consultado no sistema: " + horaAtual + "h";